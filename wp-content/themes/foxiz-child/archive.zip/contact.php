<?php
/**
 * Contact page layout partial used by page-contact.php.
 *
 * @package Foxiz Child
 */

get_header();

$admin_user = get_user_by('email', get_option('admin_email'));

if (! $admin_user instanceof WP_User) {
    $avatar_candidates = get_users(
        [
            'meta_key'   => 'author_image_id',
            'meta_value' => 0,
            'meta_compare' => '>',
            'meta_type'  => 'NUMERIC',
            'number'     => 1,
            'orderby'    => 'ID',
            'order'      => 'ASC',
        ]
    );

    if (! empty($avatar_candidates)) {
        $admin_user = $avatar_candidates[0];
    }
}

if (! $admin_user instanceof WP_User) {
    $admin_candidates = get_users(
        [
            'role__in' => ['administrator'],
            'number'   => 1,
            'orderby'  => 'ID',
            'order'    => 'ASC',
        ]
    );

    if (! empty($admin_candidates)) {
        $admin_user = $admin_candidates[0];
    }
}

$admin_user    = apply_filters('wd4_contact_admin_user', $admin_user instanceof WP_User ? $admin_user : null);
$admin_display = $admin_user instanceof WP_User ? $admin_user->display_name : get_bloginfo('name');
if (empty($admin_display)) {
    $admin_display = __('Site Administrator', 'foxiz-child');
}

$avatar_size = (int) apply_filters('wd4_contact_admin_avatar_size', 60);
if ($avatar_size <= 0) {
    $avatar_size = 60;
}

$settings = [];
if (function_exists('foxiz_get_option')) {
    $settings['logged_gravatar'] = foxiz_get_option('logged_gravatar');
}

$current_user  = $admin_user instanceof WP_User ? $admin_user : null;
$avatar_markup = '';

if ($current_user instanceof WP_User) {
    $author_image_id = (int) get_user_meta($current_user->ID, 'author_image_id', true);

    if (0 !== $author_image_id) {
        if (function_exists('foxiz_get_avatar_by_attachment')) {
            $avatar_markup = foxiz_get_avatar_by_attachment($author_image_id, 'thumbnail', false);
        }

        if (empty($avatar_markup)) {
            $avatar_markup = wp_get_attachment_image(
                $author_image_id,
                [$avatar_size, $avatar_size],
                false,
                [
                    'class'    => 'photo avatar wd4-contact-avatar-img',
                    'loading'  => 'eager',
                    'decoding' => 'async',
                    'alt'      => $admin_display,
                ]
            );
        }
    }

    if (empty($avatar_markup)) {
        $avatar_markup = get_avatar(
            $current_user->ID,
            $avatar_size,
            '',
            $admin_display,
            [
                'class'      => 'photo avatar wd4-contact-avatar-img',
                'extra_attr' => 'loading="eager" decoding="async"',
            ]
        );
    }
}

$contact_status      = isset($_GET['wd4_contact']) ? sanitize_key((string) wp_unslash($_GET['wd4_contact'])) : '';
$contact_status_code = isset($_GET['wd4_contact_code']) ? sanitize_key((string) wp_unslash($_GET['wd4_contact_code'])) : '';
$contact_notice      = '';
$contact_notice_type = '';

if ('success' === $contact_status) {
    $contact_notice_type = 'success';
    $contact_notice      = __('Thank you for your inquiry! We will get back to you soon.', 'foxiz-child');
} elseif ('error' === $contact_status) {
    $contact_notice_type = 'error';

    switch ($contact_status_code) {
        case 'invalid_nonce':
            $contact_notice = __('We could not verify your submission. Please try again.', 'foxiz-child');
            break;
        case 'missing_fields':
            $contact_notice = __('Please complete the required fields (name, email, and message) before submitting.', 'foxiz-child');
            break;
        case 'no_recipient':
            $contact_notice = __('We could not route your message at this time. Please try again later.', 'foxiz-child');
            break;
        case 'send_failed':
        default:
            $contact_notice = __('Something went wrong while sending your message. Please try again in a moment.', 'foxiz-child');
            break;
    }
}

$optin_status      = isset($_GET['wd4_optin']) ? sanitize_key((string) wp_unslash($_GET['wd4_optin'])) : '';
$optin_status_code = isset($_GET['wd4_optin_code']) ? sanitize_key((string) wp_unslash($_GET['wd4_optin_code'])) : '';
$optin_notice      = '';
$optin_notice_type = '';

if ('success' === $optin_status) {
    $optin_notice_type = 'success';
    $optin_notice      = __('Success! Check your inbox for the Glowing Testimonial Guide.', 'foxiz-child');
} elseif ('error' === $optin_status) {
    $optin_notice_type = 'error';

    switch ($optin_status_code) {
        case 'invalid_nonce':
            $optin_notice = __('We could not verify your request. Please submit the form again.', 'foxiz-child');
            break;
        case 'missing_fields':
            $optin_notice = __('Please provide a valid email address so we can send the guide.', 'foxiz-child');
            break;
        case 'no_asset':
            $optin_notice = __('The guide is not available yet. Please try again later.', 'foxiz-child');
            break;
        case 'send_failed':
        default:
            $optin_notice = __('We had trouble emailing the guide. Please try again shortly.', 'foxiz-child');
            break;
    }
}
?>

<main id="primary" class="site-main wd4-contact-page">
    <style>
        @font-face {
            font-family: 'Helvetica Neue Bold';
            src: url('https://static.showit.co/file/M_gQSc002IEHuwO1GGYBBg/146140/helveticaneuebold-webfont.woff') format('woff');
            font-weight: 700;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Helvetica Neue Light';
            src: url('https://static.showit.co/file/sDwDSb6YQgeP5ZXTtt6vuQ/146140/helveticaneuelight-webfont.woff') format('woff');
            font-weight: 300;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Helvetica Neue Light Italic';
            src: url('https://static.showit.co/file/rFyT4yqspoX-xfHW4U9hBA/146140/helveticaneuelightitalic-webfont.woff') format('woff');
            font-weight: 300;
            font-style: italic;
            font-display: swap;
        }

        @font-face {
            font-family: 'Mercenary Medium';
            src: url('https://static.showit.co/file/IN6c5sCISvwE5IHTieKwKw/146140/mercenary-medium-webfont.woff') format('woff');
            font-weight: 500;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Mercenary';
            src: url('https://usercontent.flodesk.com/68340e78-8c8d-4c4b-b370-d5f7861eff05/font/mercenarymedium.ttf') format('truetype');
            font-weight: 500;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Ivy Presto';
            src: url('https://static.showit.co/file/pwoBGetlTEGqgXEH8nOLwg/146140/ivypresto_display_thin-webfont.woff') format('woff');
            font-weight: 400;
            font-style: normal;
            font-display: swap;
        }

        @font-face {
            font-family: 'Prairie Script Bold';
            src: url('https://static.showit.co/file/pk5SX8pYRxSO3B08LdvN3g/146140/prairie-script-bold-webfont.woff') format('woff');
            font-weight: 700;
            font-style: normal;
            font-display: swap;
        }

        .wd4-contact-page {
            font-family: 'Helvetica Neue Light', 'Helvetica Neue', Helvetica, Arial, sans-serif;
            color: #1D3145;
        }

        .wd4-contact-page * {
            box-sizing: border-box;
        }

        .wd4-contact-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .wd4-contact-banner {
            background-color: #75A5CB;
            padding: 12px 20px;
            text-align: center;
            position: relative;
            z-index: 6;
        }

        .wd4-contact-banner-text {
            color: #FFFFFF;
            font-size: 15px;
            line-height: 1.4;
        }

        .wd4-contact-banner-text a {
            color: inherit;
            text-decoration: underline;
        }

        .wd4-contact-banner-close {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #FFFFFF;
            font-size: 24px;
            cursor: pointer;
            width: 28px;
            height: 28px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .wd4-contact-hero {
            position: sticky;
            top: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            min-height: clamp(520px, 100vh, 760px);
            padding: 120px 20px;
            background-color: #0b1a2d;
            background-image: linear-gradient(0deg, rgba(0, 0, 0, 0.8) 0%, transparent 100%), url('https://static.showit.co/1600/BMXlKnSZb2KncO0g1clwgg/146140/kmw-12192024-kleist-creative-brand-shoot-248.jpg');
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
            overflow: hidden;
            z-index: 0;
            transition: opacity 0.4s ease, transform 0.4s ease;
        }

        .wd4-contact-hero::before {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(0deg, rgba(0, 0, 0, 0.8) 0%, transparent 100%);
            z-index: 1;
            transition: opacity 0.4s ease;
        }

        .wd4-contact-hero-content {
            position: relative;
            z-index: 2;
            padding: 20px;
            transition: opacity 0.4s ease;
        }

        .wd4-contact-hero-subtitle {
            color: #FFFFFF;
            font-family: 'Prairie Script Bold', 'Brush Script MT', cursive;
            font-size: 20px;
            margin-bottom: 10px;
            letter-spacing: -0.1em;
        }

        .wd4-contact-hero-title {
            color: #FFFFFF;
            font-family: 'Ivy Presto', serif;
            font-size: 39px;
            line-height: 1;
            margin-bottom: 0;
        }

        .wd4-contact-hero.wd4-hero-covered {
            position: relative;
            top: auto;
            opacity: 0.25;
            transform: scale(0.97);
            z-index: -1;
            pointer-events: none;
        }

        .wd4-contact-hero.wd4-hero-covered .wd4-contact-hero-content {
            opacity: 0;
        }

        .wd4-contact-hero.wd4-hero-covered::before {
            opacity: 0.5;
        }

        .wd4-contact-section {
            position: relative;
            z-index: 1;
            background-color: #FFFFFF;
            padding: 100px 0 60px;
        }

        .wd4-contact-top-row {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            margin-bottom: 32px;
            position: sticky;
            top: 0;
            background-color: #FFFFFF;
            z-index: 100;
            padding: 20px 0;
            transition: all 0.3s ease;
            color: #132133;
            font-family: 'Mercenary Medium', 'Mercenary', sans-serif;
        }

        .wd4-contact-top-row.wd4-stuck {
            box-shadow: none;
        }

        .wd4-contact-layout {
            display: flex;
            flex-direction: column;
            gap: 40px;
        }

        .wd4-contact-left {
            background-color: #FFFFFF;
        }

        .wd4-contact-heading {
            font-family: 'Ivy Presto', serif;
            font-weight: 400;
            font-size: 36px;
            line-height: 1.1;
            margin-bottom: 24px;
            color: #1D3145;
        }

        .wd4-contact-heading-text {
            display: inline;
        }

        .wd4-contact-heading-avatar {
            display: inline-flex;
            vertical-align: baseline;
            margin-left: 0.2em;
            width: 59px;
            height: 59px;
            border-radius: 50%;
            border: 1px solid rgba(19, 33, 51, 0.2);
            background-color: #ddd;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }

        .wd4-contact-heading-avatar .logged-avatar {
            display: inline-flex;
            width: 100%;
            height: 100%;
        }

        .wd4-contact-heading-avatar .logged-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            border-radius: 50%;
        }

        .wd4-contact-heading-avatar .rbi {
            font-size: 32px;
            color: #132133;
        }

        .wd4-contact-intro {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 24px;
            max-width: 480px;
        }

        .wd4-contact-intro em {
            font-family: 'Helvetica Neue Light Italic', 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-style: normal;
        }

        .wd4-contact-intro strong,
        .wd4-contact-box strong {
            font-family: 'Helvetica Neue Bold', 'Helvetica Neue', Helvetica, Arial, sans-serif;
            font-weight: 400;
        }

        .wd4-contact-box {
            border: 1px solid rgba(19, 33, 51, 0.3);
            padding: 24px 24px 28px;
            max-width: 480px;
            background-color: #FFFFFF;
        }

        .wd4-contact-box p {
            font-size: 14px;
            line-height: 1.6;
            margin-bottom: 14px;
            text-transform: none;
        }

        .wd4-contact-box-email {
            font-size: 18px;
            color: #1D3145;
            font-family: 'Mercenary Medium', 'Mercenary', sans-serif;
            text-decoration: underline;
        }

        .wd4-contact-right {
            position: relative;
            padding: 20px 0;
            overflow: visible;
        }

        .wd4-contact-notice {
            margin-bottom: 24px;
            padding: 16px 20px;
            border-radius: 6px;
            font-size: 14px;
            line-height: 1.5;
            border: 1px solid transparent;
        }

        .wd4-contact-notice--success {
            background-color: #edf7ed;
            border-color: #c1e7c3;
            color: #1d4d1d;
        }

        .wd4-contact-notice--error {
            background-color: #fdecea;
            border-color: #f5c6cb;
            color: #611a15;
        }

        .wd4-contact-wave {
            position: absolute;
            width: 320px;
            height: 240px;
            background-repeat: no-repeat;
            background-size: contain;
            opacity: 0.55;
            pointer-events: none;
            z-index: 0;
        }

        .wd4-contact-wave-top {
            top: -60px;
            right: -60px;
            transform: scale(0.88) rotate(1deg);
        }

        .wd4-contact-wave-bottom {
            bottom: -40px;
            left: -120px;
            transform: scale(0.82) rotate(-2deg);
        }

        .wd4-contact-right > * {
            position: relative;
            z-index: 1;
        }

        .wd4-form-title {
            font-family: 'Georgia', serif;
            font-size: 22px;
            font-style: italic;
            margin-bottom: 24px;
            text-align: left;
        }

        .wd4-contact-form .wd4-form-group {
            margin-bottom: 20px;
        }

        .wd4-contact-form label {
            display: block;
            margin-bottom: 8px;
            font-size: 14px;
            font-weight: 500;
        }

        .wd4-contact-form input,
        .wd4-contact-form textarea,
        .wd4-contact-form select {
            width: 100%;
            padding: 12px 20px;
            border: 1px solid #b8b8b8;
            background-color: transparent;
            font-size: 13px;
            font-family: inherit;
            color: #1D3145;
        }

        .wd4-contact-form textarea {
            min-height: 120px;
            resize: vertical;
        }

        .wd4-form-submit {
            background-color: #5D87A9;
            color: #FFFFFF;
            padding: 12px 40px;
            border: none;
            font-size: 14px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            cursor: pointer;
            font-weight: 500;
            width: 100%;
        }

        .wd4-form-submit:hover {
            background-color: rgba(93, 135, 169, 0.8);
        }

        .wd4-faq-section {
            background-color: #335C80;
            padding: 60px 20px;
            color: #FFFFFF;
        }

        .wd4-faq-header {
            text-align: center;
            margin-bottom: 40px;
        }

        .wd4-faq-header h3 {
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            margin-bottom: 20px;
        }

        .wd4-faq-item {
            border-top: 1px solid rgba(255, 255, 255, 0.25);
            padding: 20px 0;
        }

        .wd4-faq-question {
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
        }

        .wd4-faq-question h4 {
            font-family: 'Georgia', serif;
            font-size: 24px;
            line-height: 1.2;
            flex: 1;
        }

        .wd4-faq-toggle {
            font-size: 28px;
            margin-left: 20px;
            transition: transform 0.3s;
        }

        .wd4-faq-answer {
            font-size: 16px;
            padding-top: 20px;
            display: none;
        }

        .wd4-faq-answer.wd4-active {
            display: block;
        }

        .wd4-faq-item.wd4-active .wd4-faq-toggle {
            transform: rotate(45deg);
        }

        .wd4-about-author {
            background-color: #EFEBE6;
            padding: 80px 20px;
        }

        .wd4-about-author-container {
            display: flex;
            flex-direction: column;
            gap: 40px;
            align-items: center;
        }

        .wd4-about-author-image {
            width: 100%;
        }

        .wd4-about-author-image img {
            width: 100%;
            max-width: 420px;
            height: auto;
            display: block;
            border-radius: 8px;
        }

        .wd4-about-author-content {
            max-width: 600px;
            width: 100%;
            text-align: left;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .wd4-about-author-content h3 {
            font-family: 'Mercenary Medium', 'Helvetica Neue', Arial, sans-serif;
            font-size: 16px;
            letter-spacing: 0.2em;
            text-transform: uppercase;
            color: #132133;
        }

        .wd4-about-author-content p {
            font-size: 18px;
            line-height: 1.7;
            color: #1D3145;
        }

        .wd4-optin-section {
            background-color: #161616;
            padding: 80px 20px;
            color: #FFFFFF;
        }

        .wd4-optin-content {
            max-width: 800px;
            margin: 0 auto;
            text-align: left;
        }

        .wd4-optin-title {
            font-family: 'Georgia', serif;
            font-size: 32px;
            line-height: 1.1;
            margin-bottom: 30px;
        }

        .wd4-optin-text {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 40px;
        }

        .wd4-newsletter-form {
            display: flex;
            gap: 10px;
            flex-direction: column;
        }

        .wd4-newsletter-form input {
            padding: 12px 20px;
            border: 1px solid #b8b8b8;
            background-color: transparent;
            color: #FFFFFF;
            font-size: 13px;
        }

        .wd4-newsletter-form button {
            background-color: #FFFFFF;
            color: #132133;
            padding: 12px 20px;
            border: none;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 1.3px;
            cursor: pointer;
            font-weight: 500;
        }

        @media (min-width: 768px) {
            .wd4-contact-hero {
                min-height: 80vh;
            }

            .wd4-contact-hero-subtitle {
                font-size: 30px;
            }

            .wd4-contact-hero-title {
                font-size: 101px;
            }

            .wd4-about-author-container {
                flex-direction: row;
                align-items: stretch;
                justify-content: center;
            }

            .wd4-about-author-image,
            .wd4-about-author-content {
                flex: 1;
                max-width: none;
            }

            .wd4-about-author-image {
                display: flex;
                align-items: center;
                justify-content: center;
            }

            .wd4-newsletter-form {
                flex-direction: row;
            }

            .wd4-newsletter-form input {
                flex: 1;
            }

            .wd4-newsletter-form button {
                width: auto;
            }
        }

        @media (min-width: 900px) {
            .wd4-contact-heading {
                font-size: 64px;
            }

            .wd4-contact-layout {
                display: grid;
                grid-template-columns: minmax(0, 1fr) minmax(0, 1.3fr);
                gap: 80px;
                align-items: start;
            }

            .wd4-contact-left {
                position: sticky;
                top: 100px;
                align-self: flex-start;
                height: fit-content;
                padding-bottom: 20px;
            }

            .wd4-contact-right {
                padding: 30px 40px;
            }

            .wd4-form-title {
                font-size: 26px;
                margin-bottom: 32px;
            }

            .wd4-optin-title {
                font-size: 64px;
            }
        }
    </style>

    <div class="wd4-contact-banner" id="wd4ContactBanner">
        <div class="wd4-contact-container">
            <p class="wd4-contact-banner-text">
                <strong>
                    Ever felt sooo freaking annoying while selling online? Come to
                    <a href="#" target="_self" rel="noopener">my "YOU'RE NOT ANNOYING" workshop</a>
                    to fix that!
                </strong>
            </p>
            <button class="wd4-contact-banner-close" type="button" aria-label="Close banner">
                &times;
            </button>
        </div>
    </div>

    <section class="wd4-contact-hero" id="wd4ContactHero">
        <div class="wd4-contact-hero-content">
            <p class="wd4-contact-hero-subtitle">So your story needs an author?</p>
            <h1 class="wd4-contact-hero-title">Sounds great,<br>I'll grab my pen.</h1>
        </div>
    </section>

    <section class="wd4-contact-section" id="wd4ContactSection">
        <div class="wd4-contact-container">
            <div class="wd4-contact-top-row" id="wd4ContactTopRow">
                <span>Get in touch with me</span>
                <span>Let's work together</span>
            </div>

            <div class="wd4-contact-layout">
                <div class="wd4-contact-left">
                    <h2 class="wd4-contact-heading">
                        <span class="wd4-contact-heading-text">
                            Well, actually, I'll grab my laptop... but you know what I mean.
                        </span>
                        <span class="wd4-contact-heading-avatar">
                            <?php if (! empty($avatar_markup) || ! empty($settings['logged_gravatar'])) : ?>
                                <span class="logged-avatar">
                                    <?php
                                    if (! empty($avatar_markup)) {
                                        echo $avatar_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                                    } elseif ($current_user instanceof WP_User) {
                                        echo get_avatar(
                                            $current_user->ID,
                                            $avatar_size,
                                            '',
                                            $admin_display,
                                            [
                                                'class'      => 'photo avatar wd4-contact-avatar-img',
                                                'extra_attr' => 'loading="eager" decoding="async"',
                                            ]
                                        );
                                    }
                                    ?>
                                </span>
                            <?php else : ?>
                                <i class="rbi rbi-user wnav-icon" aria-hidden="true"></i>
                            <?php endif; ?>
                        </span>
                    </h2>

                    <p class="wd4-contact-intro">
                        Whether you need fresh new copy for your website, your next online course launch,
                        your big-deal email funnel, or <em>another</em> cool copywriting project you have in mind,
                        <strong>I'm ready to get drafting.</strong>
                    </p>

                    <div class="wd4-contact-box">
                        <p>
                            <strong>
                                For inquiries about interviews, podcast appearances, guest education, and live event education, please email me directly:
                            </strong>
                        </p>
                        <p>
                            <a class="wd4-contact-box-email" href="mailto:sara@betweenthelinescopy.com">
                                sara@betweenthelinescopy.com
                            </a>
                        </p>
                    </div>
                </div>

                <div class="wd4-contact-right">
                    <span class="wd4-contact-wave wd4-contact-wave-top" aria-hidden="true" style="background-image: url('https://static.showit.co/2400/mIUAIKU2tPP2G7Wc0hrDsw/146140/sara_noel_shapes_1.png');"></span>
                    <span class="wd4-contact-wave wd4-contact-wave-bottom" aria-hidden="true" style="background-image: url('https://static.showit.co/2400/mIUAIKU2tPP2G7Wc0hrDsw/146140/sara_noel_shapes_1.png');"></span>

                    <?php if ($contact_notice) :
                        $notice_classes = 'wd4-contact-notice';
                        if ($contact_notice_type) {
                            $notice_classes .= ' wd4-contact-notice--' . $contact_notice_type;
                        }
                        $notice_role = 'success' === $contact_notice_type ? 'status' : 'alert';
                        ?>
                        <div class="<?php echo esc_attr($notice_classes); ?>" role="<?php echo esc_attr($notice_role); ?>">
                            <?php echo esc_html($contact_notice); ?>
                        </div>
                    <?php endif; ?>

                    <h2 class="wd4-form-title">Now Booking February/March 2026</h2>

                    <form class="wd4-contact-form" id="wd4ContactForm" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="wd4_contact_submit">
                        <?php wp_nonce_field('wd4_contact_submit', 'wd4_contact_nonce'); ?>
                        <div class="wd4-form-group">
                            <label for="wd4Name">Name *</label>
                            <input type="text" id="wd4Name" name="name" required>
                        </div>

                        <div class="wd4-form-group">
                            <label for="wd4Email">Email *</label>
                            <input type="email" id="wd4Email" name="email" required>
                        </div>

                        <div class="wd4-form-group">
                            <label for="wd4Business">Business Name</label>
                            <input type="text" id="wd4Business" name="business">
                        </div>

                        <div class="wd4-form-group">
                            <label for="wd4Website">Website</label>
                            <input type="url" id="wd4Website" name="website">
                        </div>

                        <div class="wd4-form-group">
                            <label for="wd4Service">What service are you interested in?</label>
                            <select id="wd4Service" name="service">
                                <option value="">Select a service</option>
                                <option value="website">Website Copywriting</option>
                                <option value="email">Email Marketing</option>
                                <option value="launch">Launch Strategy</option>
                                <option value="mentorship">Copy Mentorship</option>
                                <option value="other">Other</option>
                            </select>
                        </div>

                        <div class="wd4-form-group">
                            <label for="wd4Message">How can I serve you? *</label>
                            <textarea id="wd4Message" name="message" required></textarea>
                        </div>

                        <button type="submit" class="wd4-form-submit">Submit Inquiry</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <section class="wd4-faq-section">
        <div class="wd4-contact-container">
            <div class="wd4-faq-header">
                <h3>Frequently Asked Questions</h3>
            </div>

            <div class="wd4-faq-item">
                <div class="wd4-faq-question">
                    <h4>Do you offer payment plans?</h4>
                    <span class="wd4-faq-toggle">+</span>
                </div>
                <div class="wd4-faq-answer">
                    <p>Yes, I do! For more information, simply indicate in the "How can I serve you?" section of the above contact form that you're interested in hearing more about payment plan options.</p>
                </div>
            </div>

            <div class="wd4-faq-item">
                <div class="wd4-faq-question">
                    <h4>How far in advance should I reach out to work with you?</h4>
                    <span class="wd4-faq-toggle">+</span>
                </div>
                <div class="wd4-faq-answer">
                    <p>I typically book my projects 3-6 months in advance, so my honest answer to this question is: sooner rather than later. It's just me over here at BTL; I don't outsource projects to a team, or work with any associate writers—so I can only take on a limited amount of projects at a time.</p>
                    <p>That being said, though, if you're hoping to work together on a copy project and our timelines don't align, I do have a few other options: you can purchase my website copy guide, you can take my website copywriting course, I can audit your site for you, or I can recommend one of my many extremely talented copywriter students to connect you with.</p>
                </div>
            </div>

            <div class="wd4-faq-item">
                <div class="wd4-faq-question">
                    <h4>If you write my copy, will it still sound like me?</h4>
                    <span class="wd4-faq-toggle">+</span>
                </div>
                <div class="wd4-faq-answer">
                    <p>YES! It will absolutely sound like you. I'm committed to making your copy feel like the perfect representation of you and your brand, and I have designed my research and writing process with that in mind.</p>
                    <p>Plus, you'll fill out a detailed brand persona questionnaire prior to the start of our project, which will allow me to get to really know you, your preferences, and your voice. Then, on our kickoff call, we'll go over everything together so I can make sure that I know your voice inside and out, and am ready to accurately portray your personality!</p>
                </div>
            </div>

            <div class="wd4-faq-item">
                <div class="wd4-faq-question">
                    <h4>Do you also design websites or just write them?</h4>
                    <span class="wd4-faq-toggle">+</span>
                </div>
                <div class="wd4-faq-answer">
                    <p>I don't do any of the web design, but I do have a great (extensive) list of website designers that I've worked with and loved, for all website hosting platforms.</p>
                    <p>Simply let me know that you're looking for a designer, and I'll help you select a creator that aligns with your brand's aesthetic and goals, and the platform you intend to use. Or, if you'd prefer to use a template, I recommend purchasing one of these.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="wd4-about-author" id="wd4AboutTheAuthor">
        <div class="wd4-contact-container wd4-about-author-container">
            <div class="wd4-about-author-image">
                <img src="https://static.showit.co/400/3U3LJOFHQKOcl3RM_YfzMQ/146140/screenshot_2024-06-17_at_7_26_21_am.png" alt="Sara Noel at Lighthouse Keepers Pantry" loading="lazy">
            </div>
            <div class="wd4-about-author-content">
                <h3>About the author</h3>
                <p><strong>Sara Joelle</strong> is a copywriter and marketing mentor specializing in website and sales page copywriting, 1:1 mentorship and consulting, cheeky humor, oversharing, and the occasional bad hair day.</p>
                <p>Using her <em>sales-focused storytelling</em> method—and a well-documented obsession with writing copy that consistently gets results—Sara helps brands and businesses of all shapes and sizes connect with their ideal clients, increase their revenue, and feel confident leading their next success story.</p>
                <p>As an extrovert by nature, social anxiety's worst nightmare, and personal client cheerleader by choice, Sara is someone you'd really benefit from having in your corner. And no, she <em>definitely</em> didn't just write this whole bio about herself. Because that would be... weird. <em>*awkward laughter*</em></p>
            </div>
        </div>
    </section>

    <section class="wd4-optin-section">
        <div class="wd4-contact-container">
            <div class="wd4-optin-content">
                <h2 class="wd4-optin-title">The BTL Glowing Testimonial Guide</h2>
                <div class="wd4-optin-text">
                    <p>People love to hear from other people, and they're quick to trust their opinions, which is why adding elements of social proof on your website—like bomb reviews and testimonials—can exponentially improve the success of your business.</p>
                    <p>Download my free Glowing Testimonial Guide to get access to the exact questions I ask my clients on my own feedback form so you can start getting the best testimonials, too! And the best part? This form comes with an auto-linked spreadsheet that will organize all of your data for you. Game-changer.</p>
                </div>
                <?php if ($optin_notice) :
                    $optin_classes = 'wd4-contact-notice wd4-optin-notice';
                    if ($optin_notice_type) {
                        $optin_classes .= ' wd4-contact-notice--' . $optin_notice_type;
                    }
                    $optin_role = 'success' === $optin_notice_type ? 'status' : 'alert';
                    ?>
                    <div class="<?php echo esc_attr($optin_classes); ?>" role="<?php echo esc_attr($optin_role); ?>">
                        <?php echo esc_html($optin_notice); ?>
                    </div>
                <?php endif; ?>
                <form class="wd4-newsletter-form" id="wd4TestimonialForm" method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="wd4_testimonial_optin_submit">
                    <?php wp_nonce_field('wd4_testimonial_optin', 'wd4_testimonial_nonce'); ?>
                    <input type="text" name="first_name" placeholder="First name">
                    <input type="email" name="email" placeholder="Email address" required>
                    <button type="submit">Get the Guide</button>
                </form>
            </div>
        </div>
    </section>
</main>

<script>
    (function() {
        const banner = document.getElementById('wd4ContactBanner');
        if (banner) {
            const closeButton = banner.querySelector('.wd4-contact-banner-close');
            if (closeButton) {
                closeButton.addEventListener('click', function() {
                    banner.style.display = 'none';
                });
            }
        }

        const heroSection = document.getElementById('wd4ContactHero');
        const contactSection = document.getElementById('wd4ContactSection');
        const contactTopRow = document.getElementById('wd4ContactTopRow');

        function updateScrollEffects() {
            if (!contactSection || !contactTopRow) {
                if (heroSection) {
                    heroSection.classList.remove('wd4-hero-covered');
                }
                return;
            }

            const sectionTop = contactSection.offsetTop;
            const scrollPosition = window.pageYOffset || document.documentElement.scrollTop;

            if (scrollPosition >= sectionTop) {
                contactTopRow.classList.add('wd4-stuck');
                if (heroSection) {
                    heroSection.classList.add('wd4-hero-covered');
                }
            } else {
                contactTopRow.classList.remove('wd4-stuck');
                if (heroSection) {
                    heroSection.classList.remove('wd4-hero-covered');
                }
            }
        }

        window.addEventListener('scroll', updateScrollEffects, { passive: true });
        window.addEventListener('resize', updateScrollEffects);
        window.addEventListener('load', updateScrollEffects);
        updateScrollEffects();

        const faqItems = document.querySelectorAll('.wd4-faq-item');
        faqItems.forEach(function(item) {
            const question = item.querySelector('.wd4-faq-question');
            if (question) {
                question.addEventListener('click', function() {
                    const answer = item.querySelector('.wd4-faq-answer');
                    item.classList.toggle('wd4-active');
                    if (answer) {
                        answer.classList.toggle('wd4-active');
                    }
                });
            }
        });

    })();
</script>

<?php
get_footer();