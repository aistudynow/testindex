<?php
/**
 * Custom front page that mirrors the Elementor homepage layout while
 * remaining fully template-driven.
 *
 * @package Foxiz Child
 */

declare( strict_types=1 );

get_header();

$tagline = get_bloginfo( 'description', 'display' );
$tagline = $tagline ?: __( 'Latest stories and curated collections for AI creators.', 'foxiz-child' );

$featured_query = new WP_Query(
    array(
        'post_type'           => 'post',
        'posts_per_page'      => 1,
        'ignore_sticky_posts' => true,
        'no_found_rows'       => true,
    )
);

$featured_post = $featured_query->have_posts() ? $featured_query->posts[0] : null;
wp_reset_postdata();

$featured_post_id = $featured_post instanceof WP_Post ? (int) $featured_post->ID : 0;

$feed_query = new WP_Query(
    array(
        'post_type'           => 'post',
        'posts_per_page'      => 6,
        'ignore_sticky_posts' => true,
        'no_found_rows'       => true,
        'post__not_in'        => $featured_post_id ? array( $featured_post_id ) : array(),
    )
);

$category_sections = array(
    array(
        'slug'    => 'ai-news',
        'title'   => __( 'News', 'foxiz-child' ),
        'tagline' => __( 'View Blog', 'foxiz-child' ),
    ),
    array(
        'slug'    => 'comfyui-workflows',
        'title'   => __( 'ComfyUI Workflow', 'foxiz-child' ),
        'tagline' => __( 'View Blog', 'foxiz-child' ),
    ),
    array(
        'slug'    => 'how-to-guides',
        'title'   => __( 'How to Guide', 'foxiz-child' ),
        'tagline' => __( 'View Blog', 'foxiz-child' ),
    ),
    array(
        'slug'    => 'lora',
        'title'   => __( 'Lora', 'foxiz-child' ),
        'tagline' => __( 'View Blog', 'foxiz-child' ),
    ),
);
?>

<main id="primary" class="site-main wd4-frontpage">
    <div class="container">
        <div class="mainContainer">
            <?php if ( $featured_post instanceof WP_Post ) : ?>
                <?php
                $post = $featured_post;
                setup_postdata( $post );

                $primary_category      = get_the_category();
                $primary_category      = ! empty( $primary_category ) ? $primary_category[0] : null;
                $primary_category_link = $primary_category instanceof WP_Term ? get_category_link( $primary_category ) : '';
                $featured_meta_segments = array( get_the_date() );

                $estimated_reading_time = function_exists( 'foxiz_reading_time' ) ? foxiz_reading_time( get_the_ID() ) : '';
                if ( $estimated_reading_time ) {
                    $featured_meta_segments[] = $estimated_reading_time;
                }
                ?>
                <article <?php post_class( 'cartHolder bigCart' ); ?>>
                    <a class="storyLink" href="<?php the_permalink(); ?>"></a>
                    <figure>
                        <span>
                            <?php
                            if ( has_post_thumbnail() ) {
                                the_post_thumbnail( 'large', array( 'loading' => 'eager' ) );
                            }
                            ?>
                        </span>
                    </figure>

                    <h3 class="hdg3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

                    <div class="sortDec">
                        <?php echo esc_html( wp_trim_words( get_the_excerpt(), 40, '&hellip;' ) ); ?>
                    </div>

                    <?php
                    // No category/date metadata block on the featured card per design request.
                    ?>
                </article>
                <?php wp_reset_postdata(); ?>
            <?php endif; ?>

            <?php if ( $feed_query->have_posts() ) : ?>
                <div class="secHdg">
                    <div class="hdgTexure" aria-hidden="true"></div>
                    <span class="hdgStyle"><span><?php esc_html_e( 'Latest updates', 'foxiz-child' ); ?></span></span>
                </div>

                <?php if ( $tagline ) : ?>
                    <div class="sortDec"><?php echo esc_html( $tagline ); ?></div>
                <?php endif; ?>

                <?php
                while ( $feed_query->have_posts() ) :
                    $feed_query->the_post();

                    $primary_category      = get_the_category();
                    $primary_category      = ! empty( $primary_category ) ? $primary_category[0] : null;
                    $primary_category_link = $primary_category instanceof WP_Term ? get_category_link( $primary_category ) : '';

                    $meta_segments = array( get_the_date() );
                    $reading_time  = function_exists( 'foxiz_reading_time' ) ? foxiz_reading_time( get_the_ID() ) : '';
                    if ( $reading_time ) {
                        $meta_segments[] = $reading_time;
                    }
                    ?>
                    <article <?php post_class( 'cartHolder listView timeAgo' ); ?>>
                        <a class="storyLink" href="<?php the_permalink(); ?>"></a>
                        <figure>
                            <span>
                                <?php
                                if ( has_post_thumbnail() ) {
                                    the_post_thumbnail( 'medium', array( 'loading' => 'lazy' ) );
                                }
                                ?>
                            </span>
                        </figure>

                        <h3 class="hdg3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

                        <div class="actionDiv flexElm">
                            <?php if ( $primary_category instanceof WP_Term && ! is_wp_error( $primary_category_link ) ) : ?>
                                <div class="secName">
                                    <a href="<?php echo esc_url( $primary_category_link ); ?>"><?php echo esc_html( $primary_category->name ); ?></a>
                                </div>
                            <?php endif; ?>
                            <div class="dateTime"><?php echo esc_html( implode( ' · ', array_filter( $meta_segments ) ) ); ?></div>
                        </div>
                    </article>
                    <?php
                endwhile;
                wp_reset_postdata();
                ?>
            <?php else : ?>
                <div class="cartHolder">
                    <div class="sortDec"><?php esc_html_e( 'Publish a few posts to populate the feed.', 'foxiz-child' ); ?></div>
                </div>
            <?php endif; ?>

            <?php
            foreach ( $category_sections as $section ) :
                $term = get_category_by_slug( $section['slug'] );

                if ( ! ( $term instanceof WP_Term ) ) {
                    continue;
                }

                $section_link  = get_category_link( $term );
                $section_query = new WP_Query(
                    array(
                        'post_type'           => 'post',
                        'posts_per_page'      => 10,
                        'ignore_sticky_posts' => true,
                        'no_found_rows'       => true,
                        'tax_query'           => array(
                            array(
                                'taxonomy' => 'category',
                                'field'    => 'slug',
                                'terms'    => $section['slug'],
                            ),
                        ),
                    )
                );

                if ( ! $section_query->have_posts() ) {
                    continue;
                }
                ?>
                <div class="mt20">
                    <div class="secHdg">
                        <div class="hdgTexure" aria-hidden="true"></div>
                        <span class="hdgStyle"><span><?php echo esc_html( $section['title'] ); ?></span></span>
                    </div>

                    <div class="htSlider">
                        <div class="htsHeader">
                            <div class="hdg2">
                                <?php if ( ! is_wp_error( $section_link ) && $section_link ) : ?>
                                    <a href="<?php echo esc_url( $section_link ); ?>"><?php echo esc_html( $section['title'] ); ?></a>
                                <?php else : ?>
                                    <?php echo esc_html( $section['title'] ); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                        <ul>
                            <?php
                            while ( $section_query->have_posts() ) :
                                $section_query->the_post();

                                $primary_category      = get_the_category();
                                $primary_category      = ! empty( $primary_category ) ? $primary_category[0] : null;
                                $primary_category_link = $primary_category instanceof WP_Term ? get_category_link( $primary_category ) : '';
                                ?>
                                <li <?php post_class(); ?>>
                                    <figure>
                                        <span>
                                            <?php
                                            if ( has_post_thumbnail() ) {
                                                the_post_thumbnail( 'medium', array( 'loading' => 'lazy' ) );
                                            }
                                            ?>
                                        </span>
                                    </figure>
                                    <p><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></p>
                                    <div class="actionDiv flexElm">
                                        <?php if ( $primary_category instanceof WP_Term && ! is_wp_error( $primary_category_link ) ) : ?>
                                            <div class="secName">
                                                <a href="<?php echo esc_url( $primary_category_link ); ?>"><?php echo esc_html( $primary_category->name ); ?></a>
                                            </div>
                                        <?php endif; ?>
                                        <div class="dateTime"><?php echo esc_html( get_the_date() ); ?></div>
                                    </div>
                                </li>
                                <?php
                            endwhile;
                            wp_reset_postdata();
                            ?>
                        </ul>
                    </div>

                    <?php if ( ! is_wp_error( $section_link ) && $section_link ) : ?>
                        <div class="viewMoreButton">
                            <a href="<?php echo esc_url( $section_link ); ?>"><?php echo esc_html( $section['tagline'] ); ?></a>
                        </div>
                    <?php endif; ?>
                </div>
                <?php
            endforeach;
            ?>
        </div>
    </div>
</main>

<?php
get_footer();